﻿using System.Reflection;

[assembly: AssemblyTitle("Sensibo_Air")]
[assembly: AssemblyCompany("HP Inc.")]
[assembly: AssemblyProduct("Sensibo_Air")]
[assembly: AssemblyCopyright("Copyright © HP Inc. 2021")]
[assembly: AssemblyVersion("1.0.0.*")]

