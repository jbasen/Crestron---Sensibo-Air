﻿using System;
using System.Text;
using Crestron.SimplSharp;                          				// For Basic SIMPL# Classes
using Crestron.SimplSharp.Net.Https;
using Newtonsoft.Json;

namespace Sensibo_Air_Integration
{
	#region Delegates
	public delegate void DelegateFn(ushort Device_On, ushort mode, ushort fan_level, ushort target_temperature, SimplSharpString temperature_unit, ushort swing, 
		ushort horizontal_swing, ushort light, ushort climate_react, short temperature, ushort humidity);
	#endregion

	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	#endregion

	public class Sensibo_Air
	{
		public DelegateFn callback_fn { get; set; }

		#region Declarations
		private string API_Key;
		private string Device_ID;
		private static Debug_Options Debug;
		private bool Current_Power_State;
		private string Current_Mode;
		private string Current_Fan_Level;
		private int Current_Target_Temperature = 0;
		private string Current_Temperature_Unit = string.Empty;
		private string Current_Swing;
		private string Current_Horizontal_Swing;
		private string Current_Light;
		#endregion

		//****************************************************************************************
		// 
		//  Sensibo_Air	-	Default Constructor
		// 
		//****************************************************************************************
		public Sensibo_Air()
		{
		}

		//****************************************************************************************
		// 
		//  Initialize	-	Initialization
		// 
		//****************************************************************************************
		public void Initialize(string Device_ID, string API_Key, short Default_Target_Temperature, string Default_Temperature_Unit, short Debug)
		{
			#region Save Parameters
			this.API_Key = API_Key;
			this.Device_ID = Device_ID;
			#endregion

			Set_Debug_Message_Output(Debug);

			Refresh();

			#region Handle when starting up and unit in fan mode
			if (Current_Target_Temperature == 0)
			{
				Current_Target_Temperature = Default_Target_Temperature;
			}

			if (Current_Temperature_Unit == string.Empty)
			{
				Current_Temperature_Unit = Default_Temperature_Unit;
			}
			#endregion

			Debug_Message("Initialize", "SUCCESS");
		}

		//****************************************************************************************
		// 
		//  Refresh	-	Get Device status
		// 
		//****************************************************************************************
		public void Refresh()
		{
			string url = "";

			Debug_Message("Refresh", "Start");

			#region Error Checking
			if (string.IsNullOrEmpty(API_Key))
			{
				string err = "Sensibo_Air - Refresh - API_Key Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}
			else if (string.IsNullOrEmpty(Device_ID))
			{
				string err = "Sensibo_Air - Refresh - Device_ID Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}
			#endregion

			#region Create url
			url = "https://home.sensibo.com/api/v2/pods/" + Device_ID + "?fields=*&apiKey=" + API_Key;
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpsClient client = new HttpsClient();
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Sensibo_Air - Refresh - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					Debug_Message("Refresh", "ContentString = " + response.ContentString);
					Manage_Sensibo_Response(response.ContentString);
				}
			}
			catch (Exception e)
			{
				string err = "Sensibo_Air - Refresh - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Set_Power	-	turn power on/off
		// 
		//****************************************************************************************
		public void Set_Power(string power_on)
		{
			string url = "";
			string payload = "";

			Debug_Message("Set_Power", "Start");

			#region Error Checking
			if (string.IsNullOrEmpty(API_Key))
			{
				string err = "Sensibo_Air - Set_Power - API_Key Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			else if (string.IsNullOrEmpty(Device_ID))
			{
				string err = "Sensibo_Air - Set_Power - Device_ID Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion

			#region Create url
			url = "https://home.sensibo.com/api/v2/pods/" + Device_ID + "/acStates?apiKey=" + API_Key;
			Debug_Message("Set_Power", "url = " + url);
			#endregion

			#region Create Payload
			payload = Create_Payload(((power_on == "true")? true : false), this.Current_Mode, this.Current_Fan_Level, this.Current_Target_Temperature, 
				this.Current_Temperature_Unit, this.Current_Swing, this.Current_Horizontal_Swing, this.Current_Light);
			Debug_Message("Set_Power", "payload = " + payload);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpsClient client = new HttpsClient();
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Post;
				request.ContentString = payload;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(payload.Length));
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Sensibo_Air - Set_Power - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
			}
			catch (Exception e)
			{
				string err = "Sensibo_Air - Set_Power - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Set_Mode	-	set connected device mode
		// 
		//****************************************************************************************
		public void Set_Mode(string Mode)
		{
			string url = "";
			string payload = "";

			Debug_Message("Set_Mode", "Start");

			#region Error Checking
			if (string.IsNullOrEmpty(API_Key))
			{
				string err = "Sensibo_Air - Set_Mode - API_Key Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			else if (string.IsNullOrEmpty(Device_ID))
			{
				string err = "Sensibo_Air - Set_Mode - Device_ID Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion

			#region Create url
			url = "https://home.sensibo.com/api/v2/pods/" + Device_ID + "/acStates?apiKey=" + API_Key;
			Debug_Message("Set_Mode", "url = " + url);
			#endregion

			#region Create Payload
			payload = Create_Payload(true, Mode, this.Current_Fan_Level, this.Current_Target_Temperature, 
				this.Current_Temperature_Unit, this.Current_Swing, this.Current_Horizontal_Swing, this.Current_Light);

			//Save Mode and power so temp, etc. commands can rapidly be sent after mode command
			//if command fails Refresh sent later will fix the status
			this.Current_Mode = Mode;
			this.Current_Power_State = true;
		
			Debug_Message("Set_Mode", "payload = " + payload);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpsClient client = new HttpsClient();
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Post;
				request.ContentString = payload;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(payload.Length));
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Sensibo_Air - Set_Mode - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
			}
			catch (Exception e)
			{
				string err = "Sensibo_Air - Set_Mode - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Set_Fan_Level	-	set connected device fan level
		// 
		//****************************************************************************************
		public void Set_Fan_Level(string Fan_Level)
		{
			string url = "";
			string payload = "";

			Debug_Message("Set_Fan_Level", "Start");

			#region Error Checking
			if (string.IsNullOrEmpty(API_Key))
			{
				string err = "Sensibo_Air - Set_Fan_Level - API_Key Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			else if (string.IsNullOrEmpty(Device_ID))
			{
				string err = "Sensibo_Air - Set_Fan_Level - Device_ID Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion

			#region Create url
			url = "https://home.sensibo.com/api/v2/pods/" + Device_ID + "/acStates?apiKey=" + API_Key;
			Debug_Message("Set_Fan_Level", "url = " + url);
			#endregion

			#region Create Payload
			payload = Create_Payload(this.Current_Power_State, this.Current_Mode, Fan_Level, this.Current_Target_Temperature, 
				this.Current_Temperature_Unit, this.Current_Swing, this.Current_Horizontal_Swing, this.Current_Light);
			Debug_Message("Set_Fan_Level", "payload = " + payload);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpsClient client = new HttpsClient();
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Post;
				request.ContentString = payload;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(payload.Length));
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Sensibo_Air - Set_Fan_Level - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
			}
			catch (Exception e)
			{
				string err = "Sensibo_Air - Set_Fan_Level - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Set_Swing	-	set connected device swing
		// 
		//****************************************************************************************
		public void Set_Swing(string swing)
		{
			string url = "";
			string payload = "";

			Debug_Message("Set_Swing", "Start");

			#region Error Checking
			if (string.IsNullOrEmpty(API_Key))
			{
				string err = "Sensibo_Air - Set_Swing - API_Key Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			else if (string.IsNullOrEmpty(Device_ID))
			{
				string err = "Sensibo_Air - Set_Swing - Device_ID Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion

			#region Create url
			url = "https://home.sensibo.com/api/v2/pods/" + Device_ID + "/acStates?apiKey=" + API_Key;
			Debug_Message("Set_Swing", "url = " + url);
			#endregion

			#region Create Payload
			payload = Create_Payload(this.Current_Power_State, this.Current_Mode, this.Current_Fan_Level, this.Current_Target_Temperature,
				this.Current_Temperature_Unit, swing, this.Current_Horizontal_Swing, this.Current_Light);
			Debug_Message("Set_Swing", "payload = " + payload);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpsClient client = new HttpsClient();
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Post;
				request.ContentString = payload;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(payload.Length));
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Sensibo_Air - Set_Swing - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
			}
			catch (Exception e)
			{
				string err = "Sensibo_Air - Set_Swing - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Set_Horizontal_Swing	-	set connected device horizontal swing
		// 
		//****************************************************************************************
		public void Set_Horizontal_Swing(string horizontal_swing)
		{
			string url = "";
			string payload = "";

			Debug_Message("Set_Horizontal_Swing", "Start");

			#region Error Checking
			if (string.IsNullOrEmpty(API_Key))
			{
				string err = "Sensibo_Air - Set_Horizontal_Swing - API_Key Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			else if (string.IsNullOrEmpty(Device_ID))
			{
				string err = "Sensibo_Air - Set_Horizontal_Swing - Device_ID Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion

			#region Create url
			url = "https://home.sensibo.com/api/v2/pods/" + Device_ID + "/acStates?apiKey=" + API_Key;
			Debug_Message("Set_Horizontal_Swing", "url = " + url);
			#endregion

			#region Create Payload
			payload = Create_Payload(this.Current_Power_State, this.Current_Mode, this.Current_Fan_Level, this.Current_Target_Temperature,
				this.Current_Temperature_Unit, this.Current_Swing, horizontal_swing, this.Current_Light);
			Debug_Message("Set_Horizontal_Swing", "payload = " + payload);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpsClient client = new HttpsClient();
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Post;
				request.ContentString = payload;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(payload.Length));
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Sensibo_Air - Set_Horizontal_Swing - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
			}
			catch (Exception e)
			{
				string err = "Sensibo_Air - Set_Horizontal_Swing - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Set_Light	-	set connected device light
		// 
		//****************************************************************************************
		public void Set_Light(string light)
		{
			string url = "";
			string payload = "";

			Debug_Message("Set_Light", "Start");

			#region Error Checking
			if (string.IsNullOrEmpty(API_Key))
			{
				string err = "Sensibo_Air - Set_Light - API_Key Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			else if (string.IsNullOrEmpty(Device_ID))
			{
				string err = "Sensibo_Air - Set_Light - Device_ID Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion

			#region Create url
			url = "https://home.sensibo.com/api/v2/pods/" + Device_ID + "/acStates?apiKey=" + API_Key;
			Debug_Message("Set_Light", "url = " + url);
			#endregion

			#region Create Payload
			payload = Create_Payload(this.Current_Power_State, this.Current_Mode, this.Current_Fan_Level, this.Current_Target_Temperature,
				this.Current_Temperature_Unit, this.Current_Swing, this.Current_Horizontal_Swing, light);
			Debug_Message("Set_Light", "payload = " + payload);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpsClient client = new HttpsClient();
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Post;
				request.ContentString = payload;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(payload.Length));
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Sensibo_Air - Set_Light - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
			}
			catch (Exception e)
			{
				string err = "Sensibo_Air - Set_Light - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Set_Target_Temperature	-	set connected device target temperature
		// 
		//****************************************************************************************
		public void Set_Target_Temperature(int Target_Temperature)
		{
			string url = "";
			string payload = "";

			Debug_Message("Set_Target_Temperature", "Start");

			#region Error Checking
			if (string.IsNullOrEmpty(API_Key))
			{
				string err = "Sensibo_Air - Set_Target_Temperature - API_Key Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			else if (string.IsNullOrEmpty(Device_ID))
			{
				string err = "Sensibo_Air - Set_Target_Temperature - Device_ID Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion

			#region Create url
			url = "https://home.sensibo.com/api/v2/pods/" + Device_ID + "/acStates?apiKey=" + API_Key;
			Debug_Message("Set_Target_Temperature", "url = " + url);
			#endregion

			#region Create Payload
			payload = Create_Payload(this.Current_Power_State, this.Current_Mode, this.Current_Fan_Level, Target_Temperature, 
				this.Current_Temperature_Unit, this.Current_Swing, this.Current_Horizontal_Swing, this.Current_Light);
			Debug_Message("Set_Target_Temperature", "payload = " + payload);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpsClient client = new HttpsClient();
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Post;
				request.ContentString = payload;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(payload.Length));
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Sensibo_Air - Set_Target_Temperature - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
			}
			catch (Exception e)
			{
				string err = "Sensibo_Air - Set_Target_Temperature - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Set_Climate_React	-	enable/disable climate react
		// 
		//****************************************************************************************
		public void Set_Climate_React(string climate_react)
		{
			string url = "";
			string payload = "";

			Debug_Message("Set_Climate_React", "Start");

			#region Error Checking
			if (string.IsNullOrEmpty(API_Key))
			{
				string err = "Sensibo_Air - Set_Climate_React - API_Key Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			else if (string.IsNullOrEmpty(Device_ID))
			{
				string err = "Sensibo_Air - Set_Climate_React - Device_ID Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion

			#region Create url
			url = "https://home.sensibo.com/api/v2/pods/" + Device_ID + "/smartmode?apiKey=" + API_Key;
			Debug_Message("Set_Climate_React", "url = " + url);
			#endregion

			#region Create Payload
			payload = "{\"enabled\": " + climate_react + "}";
			Debug_Message("Set_Climate_React", "payload = " + payload);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpsClient client = new HttpsClient();
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Put;
				request.ContentString = payload;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(payload.Length));
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Sensibo_Air - Set_Climate_React - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
			}
			catch (Exception e)
			{
				string err = "Sensibo_Air - Set_Climate_React - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Create_Payload	-	Handles JSON responses from the Sensibo Air
		// 
		//****************************************************************************************
		private string Create_Payload(bool Power_State, string Mode, string Fan_Level, int Target_Temperature, string Temperature_Unit, string Swing, string Horizontal_Swing, string Light)
		{
			return "{\"acState\": {\"on\": " + Power_State.ToString().ToLower() + ", \"mode\": \"" + Mode + "\", \"fanLevel\": \"" + Fan_Level + "\", \"targetTemperature\": " + Target_Temperature
				+ ", \"temperatureUnit\": \"" + Temperature_Unit + "\", \"swing\": \"" + Swing + "\", \"horizontalSwing\": \"" + Horizontal_Swing + "\", \"light\": \"" + Light + "\"}}";
		}

		//****************************************************************************************
		// 
		//  Manage_Sensibo_Response	-	Handles JSON responses from the Sensibo Air
		// 
		//****************************************************************************************
		private void Manage_Sensibo_Response(string ContentString)
		{

			#region Parse asState info from returned json
			string s = ContentString;
			int i = s.IndexOf("\"acState\"", 0);
			i = s.IndexOf("{", i);
			int j = Extract_Json_Section(s, i);
			s = s.Substring(i, (j - i) + 1);
			Debug_Message("Refresh - acState", "s = " + s);
			acState state = acState.Parse(s);
			if (state == null)
			{
				return;
			}
			#endregion

			#region Save to Globals
			this.Current_Power_State = state.on;
			this.Current_Mode = state.mode;
			this.Current_Fan_Level = state.fanLevel;
			if (state.targetTemperature != 0)//will be in fan mode
			{
				this.Current_Target_Temperature = state.targetTemperature;
			}
			if (state.temperatureUnit != string.Empty)//will be in fan mode
			{
				this.Current_Temperature_Unit = state.temperatureUnit;
			}
			this.Current_Swing = state.swing;
			this.Current_Horizontal_Swing = state.horizontalSwing;
			this.Current_Light = state.light;
			#endregion

			#region Parse Temperature and Humidity
			s = ContentString;
			i = s.IndexOf("\"measurements\"", 0);
			i = s.IndexOf("{", i);
			j = Extract_Json_Section(s, i);
			s = s.Substring(i, (j - i) + 1);
			Debug_Message("Refresh - measurements", "s = " + s);
			measurements temp_humidity = measurements.Parse(s);
			if (temp_humidity == null)
			{
				return;
			}
			#endregion

			#region Parse Climate React
			s = ContentString;
			string climate_react = Parse_Data_Substring(s, "", "\"smartMode\": {\"enabled\": ", ",");
			if (climate_react == "null")
			{
				climate_react = "false";
			}
			#endregion

			#region Send Back to S+
			#region Power
			ushort Device_On = (state.on == true) ? (ushort)1 : (ushort)0;
			#endregion

			#region Mode
			ushort mode;
			if (state.mode != null)
			{
				switch (state.mode)
				{
					case "cool":
						mode = 1;
						break;

					case "heat":
						mode = 2;
						break;

					case "dry":
						mode = 3;
						break;

					case "fan":
						mode = 4;
						break;

					case "auto":
						mode = 5;
						break;

					default:
						mode = 0;
						break;
				}
			}
			else
			{
				mode = 0;
			}
			#endregion

			#region Fan Level
			ushort fan_level;
			if (state.fanLevel != null)
			{
				switch (state.fanLevel)
				{
					case "quiet":
						fan_level = 1;
						break;

					case "low":
						fan_level = 2;
						break;

					case "medium_low":
						fan_level = 3;
						break;

					case "medium":
						fan_level = 4;
						break;

					case "medium_high":
						fan_level = 5;
						break;

					case "high":
						fan_level = 6;
						break;

					case "strong":
						fan_level = 7;
						break;

					case "auto":
						fan_level = 8;
						break;

					default:
						fan_level = 0;
						break;
				}
			}
			else
			{
				fan_level = 0;
			}
			#endregion

			#region Swing
			ushort swing;
			if (state.swing != null)
			{
				switch (state.swing)
				{
					case "stopped":
						swing = 1;
						break;

					case "fixedTop":
						swing = 2;
						break;

					case "fixedMiddleTop":
						swing = 3;
						break;

					case "fixedMiddle":
						swing = 4;
						break;

					case "fixedMiddleBottom":
						swing = 5;
						break;

					case "fixedBottom":
						swing = 6;
						break;

					case "rangeTop":
						swing = 7;
						break;

					case "rangeMiddle":
						swing = 8;
						break;

					case "rangeBottom":
						swing = 9;
						break;

					case "rangeFull":
						swing = 10;
						break;

					case "horizontal":
						swing = 11;
						break;

					case "both":
						swing = 12;
						break;

					default:
						swing = 0;
						break;
				}
			}
			else
			{
				swing = 0;
			}
			#endregion

			#region Horizontal Swing
			ushort horizontal_swing;
			if (state.horizontalSwing != null)
			{
				switch (state.horizontalSwing)
				{
					case "stopped":
						horizontal_swing = 1;
						break;

					case "fixedLeft":
						horizontal_swing = 2;
						break;

					case "fixedCenterLeft":
						horizontal_swing = 3;
						break;

					case "fixedCenterRight":
						horizontal_swing = 4;
						break;

					case "fixedRight":
						horizontal_swing = 5;
						break;

					case "fixedLeftRight":
						horizontal_swing = 6;
						break;

					case "fixedCenter":
						horizontal_swing = 7;
						break;

					case "rangeCenter":
						horizontal_swing = 8;
						break;

					case "rangeLeft":
						horizontal_swing = 9;
						break;

					case "rangeRight":
						horizontal_swing = 10;
						break;

					case "rangeFull":
						horizontal_swing = 11;
						break;

					default:
						horizontal_swing = 0;
						break;
				}
			}
			else
			{
				horizontal_swing = 0;
			}
			#endregion

			#region Light
			ushort light;
			if (state.light != null)
			{
				switch (state.light)
				{
					case "off":
						light = 1;
						break;

					case "on":
						light = 2;
						break;

					case "dim":
						light = 3;
						break;

					default:
						light = 0;
						break;
				}
			}
			else
			{
				light = 0;
			}
			#endregion

			#region Target Temperature
			ushort target_temperature;
			if (state.mode != "fan")
			{
				target_temperature = (ushort)state.targetTemperature;
			}
			else
			{
				target_temperature = 0;
			}
			#endregion

			#region Temperature Unit
			string temperature_unit;
			if (state.mode != "fan")
			{
				temperature_unit = state.temperatureUnit;
			}
			else
			{
				temperature_unit = "";
			}
			#endregion

			#region Temperature and Humidity
			if (state.temperatureUnit.ToUpper() == "F")
			{
				temp_humidity.temperature = (temp_humidity.temperature * 1.8) + 32;//convert from celcius to fahrenheit
			}
			short temperature = (short)Math.Round(temp_humidity.temperature, 0);
			ushort humidity = (ushort)Math.Round(temp_humidity.humidity, 0);
			#endregion

			#region Climate React
			ushort Climate_React_State = (climate_react == "true") ? (ushort)1 : (ushort)0;
			#endregion

			callback_fn(Device_On, mode, fan_level, target_temperature, temperature_unit, swing, horizontal_swing, light, Climate_React_State, temperature, humidity);
			#endregion
		}

		//****************************************************************************************
		// 
		//  Extract_Json_Section	-	Extract a specific section from a larger json string
		//                              Note - string s is expected to start with a {
		// 
		//****************************************************************************************
		int Extract_Json_Section(string s, int start_index)
		{
			int i;
			int brace_count = 0;
			//loop through string
			for (i = start_index; i < s.Length; i++)
			{
				//find match to intial open brace
				if (s[i] == '{')
				{
					brace_count++;
				}
				else if (s[i] == '}')
				{
					brace_count--;
				}
				if (brace_count == 0)
				{
					break;//exit loop when found
				}
			}
			return i;
		}

		//****************************************************************************************
		// 
		//  Parse_Data_Substring	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		private string Parse_Data_Substring(string s, string section, string id, string ending_char)
		{
			int index1, index2, section_index;

			//Reporting of not finding section or string as an error eliminted because 
			//there are too many situations where the code has to accomodate the fact
			//that hubitat will send back very different messages depending on exactly
			//what setting was changed on a device.  Thermostat is the prime example

			//if data element located within a specific section of json, go to that section
			if (section != "")
			{
				section_index = s.IndexOf(section, 0);
				if (section_index == -1)
				{
					//CrestronConsole.PrintLine("Hubitat-Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					//Crestron.SimplSharp.ErrorLog.Error("Hubitat-Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					return "";
				}
				else
				{
					section_index += section.Length;
				}
			}
			else
			{
				section_index = 0;
			}

			//get index to start of value
			index1 = s.IndexOf(id, section_index);
			if (index1 == -1)
			{
				//CrestronConsole.PrintLine("Hubitat-Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				//Crestron.SimplSharp.ErrorLog.Error("Hubitat-Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				return "";
			}
			else
			{
				index1 += id.Length;
			}

			//get index to end of value
			index2 = s.IndexOf(ending_char, (index1 + 1));
			if (index2 == -1)
			{
				CrestronConsole.PrintLine("Sensibo_Air - Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("Sensibo_Air - Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				return "";
			}

			//get value substring and pass it back
			return s.Substring(index1, index2 - index1);
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					Sensibo_Air.Debug = Debug_Options.None;
					break;

				case 1:
					Sensibo_Air.Debug = Debug_Options.Console;
					break;

				case 2:
					Sensibo_Air.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					Sensibo_Air.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 200;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("Sensibo_Air - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("Sensibo_Air - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}

	}
	//****************************************************************************************
	// 
	//  acState	-	Class for parsing acState info
	// 
	//****************************************************************************************
	public class acState
	{
		#region Declarations
		public bool on { get; set; }
		public string mode { get; set; }
		public string fanLevel { get; set; }
		public int targetTemperature { get; set; }
		public string temperatureUnit { get; set; }
		public string swing { get; set; }
		public string horizontalSwing { get; set; }
		public string light { get; set; }
		#endregion

		//****************************************************************************************
		// 
		//  Parse	-	Parse acState from Json
		// 
		//****************************************************************************************
		public static acState Parse(string JSON)
		{
			try
			{
				acState Data = JsonConvert.DeserializeObject<acState>(JSON);
				#region Eliminate any nulls
				if (Data.mode == null)
				{
					Data.mode = "";
				}

				if (Data.fanLevel == null)
				{
					Data.fanLevel = "";
				}

				if (Data.temperatureUnit == null)
				{
					Data.temperatureUnit = "";
				}

				if (Data.swing == null)
				{
					Data.swing = "";
				}

				if (Data.horizontalSwing == null)
				{
					Data.horizontalSwing = "";
				}

				if (Data.light == null)
				{
					Data.light = "";
				}

				#endregion
				return Data;
			}
			catch (Exception e)
			{
				string err = "Sensibo Air - acState - Parse - Error Parsing JSON: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return null;
			}
		}
	}

	//****************************************************************************************
	// 
	//  measurements	-	Class for parsing temperature and humidity
	// 
	//****************************************************************************************
	public class measurements
	{
		#region Declarations
		public double temperature { get; set; }
		public double humidity { get; set; }
		#endregion

		//****************************************************************************************
		// 
		//  Parse	-	Parse acState from Json
		// 
		//****************************************************************************************
		public static measurements Parse(string JSON)
		{
			try
			{
				measurements Data = JsonConvert.DeserializeObject<measurements>(JSON);
				return Data;
			}
			catch (Exception e)
			{
				string err = "Sensibo Air - measurements - Parse - Error Parsing JSON: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return null;
			}
		}
	}

}
